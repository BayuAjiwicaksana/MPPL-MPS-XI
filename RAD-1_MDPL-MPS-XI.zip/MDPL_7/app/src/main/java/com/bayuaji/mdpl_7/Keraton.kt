package com.bayuaji.mdpl_7

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Keraton : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keraton)

        val btnMaps = findViewById<Button>(R.id.maps_keraton)

        btnMaps.setOnClickListener {
            val linkMaps = Uri.parse("https://goo.gl/maps/JPoi561g2kL3MbLx6")

            val mapIntent = Intent(Intent.ACTION_VIEW, linkMaps)

            mapIntent.setPackage("com.google.android.apps.maps")

            startActivity(mapIntent)
        }
    }
}