package com.bayuaji.mdpl_7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val parangtritis = findViewById<LinearLayout>(R.id.menu_parangtritis)
        val prambanan = findViewById<LinearLayout>(R.id.menu_prambanan)
        val borobudur = findViewById<LinearLayout>(R.id.menu_borobudur)
        val keraton = findViewById<LinearLayout>(R.id.menu_keraton)
        val malioboro = findViewById<LinearLayout>(R.id.menu_malioboro)

        parangtritis.setOnClickListener {
            val intent = Intent(this, Parangtritis::class.java)
            startActivity(intent)
        }

        borobudur.setOnClickListener {
            val intent = Intent(this, Borobudur::class.java)
            startActivity(intent)
        }

        malioboro.setOnClickListener {
            val intent = Intent(this, Malioboro::class.java)
            startActivity(intent)
        }

        prambanan.setOnClickListener {
            val intent = Intent(this, Prambanan::class.java)
            startActivity(intent)
        }

        keraton.setOnClickListener {
            val intent = Intent(this, Keraton::class.java)
            startActivity(intent)
        }
    }
}