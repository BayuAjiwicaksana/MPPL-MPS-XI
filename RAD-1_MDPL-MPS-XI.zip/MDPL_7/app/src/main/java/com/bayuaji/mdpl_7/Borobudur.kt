package com.bayuaji.mdpl_7

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Borobudur : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_borobudur)

        val btnMaps = findViewById<Button>(R.id.maps_borobudur)

        btnMaps.setOnClickListener {
            val linkMaps = Uri.parse("https://goo.gl/maps/kM4bsDeA7wFQWWqi9")

            val mapIntent = Intent(Intent.ACTION_VIEW, linkMaps)

            mapIntent.setPackage("com.google.android.apps.maps")

            startActivity(mapIntent)
        }
    }
}