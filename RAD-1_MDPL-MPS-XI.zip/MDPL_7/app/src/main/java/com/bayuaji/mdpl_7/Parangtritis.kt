package com.bayuaji.mdpl_7

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Parangtritis : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parangtritis)

        val btnMaps = findViewById<Button>(R.id.maps_parangtritis)

        btnMaps.setOnClickListener {
            val linkMaps = Uri.parse("https://goo.gl/maps/NNBU1sTPfjyJo6Bp8")

            val mapIntent = Intent(Intent.ACTION_VIEW, linkMaps)

            mapIntent.setPackage("com.google.android.apps.maps")

            startActivity(mapIntent)
        }
    }
}