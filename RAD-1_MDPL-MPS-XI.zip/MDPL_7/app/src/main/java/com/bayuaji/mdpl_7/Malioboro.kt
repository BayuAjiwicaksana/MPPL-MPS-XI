package com.bayuaji.mdpl_7

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Malioboro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_malioboro)

        val btnMaps = findViewById<Button>(R.id.maps_malioboro)

        btnMaps.setOnClickListener {
            val linkMaps = Uri.parse("https://goo.gl/maps/Gjhsy9JF9xtNpAo99")

            val mapIntent = Intent(Intent.ACTION_VIEW, linkMaps)

            mapIntent.setPackage("com.google.android.apps.maps")

            startActivity(mapIntent)
        }
    }
}